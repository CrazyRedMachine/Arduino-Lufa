#!/usr/bin/env python3
from activate import deactivate
"""
Script to deactivate LUFA for Arduino.
More info can be found in the activate.py script.
"""

if __name__ == '__main__':
    deactivate()
