#!/usr/bin/env python3
from activate import install
"""
Script to install LUFA boards for Arduino.
More info can be found in the activate.py script.
"""

if __name__ == '__main__':
    install()
