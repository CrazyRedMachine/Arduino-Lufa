/**
 * For convinience, you can declare these in where you want to use
 * the Arduino-style Serial.
 */
#include <LUFACDCSerial.h>

extern LUFACDCSerial SerialU1;
extern LUFACDCSerial SerialU2;
